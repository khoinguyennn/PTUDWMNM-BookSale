<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>--oO sachhay.com Oo--</title>
<link rel="stylesheet" type="text/css" href="css.css" />
</head>

<body bgcolor="#999999">
<center>
<table width="1000" border="1" cellspacing="0" bordercolor="#003300" cellpadding="0" style="box-shadow: #6C0 0px 30px 150px;">
    <tr>
    	<td colspan="3" height="200" background="hinhanh/sachhay_new1.gif"></td>
    </tr>
    <tr  bgcolor="#92D84E">
    	<td colspan="3">
        	<table border="0" width="100%" cellpadding="0" cellspacing="0">
            	<tr>
                	<td width="80"><a id="thuong" href="./">Trang chủ</a></td>
                    <td><font color="#FF6600"><marquee>Cùng bạn đi tìm tri thức!</marquee></font></td>
             </tr>
            </table>
        </td>
    </tr>
    <tr >
    	<td width="200" align="left" valign="top" bgcolor="#92D84E">
        	<table border="1" cellspacing="0" width="100%" cellpadding="0" bordercolor="#003300">
            	<tr>
                	<th><font color="#FF6600">Bài tập PHP căn bản</font></th>
                </tr>
                <tr>
                    <td><a href="#">BT1 - Máy tính</a></td>
                </tr>
                <tr>
                    <td><a href="#">BT2 - Giải PT bậc I một ẩn</a></td>
                </tr>
                <tr>
                    <td><a href="#">BT3 - Giải PT bậc II một ẩn</a></td>
                </tr>
                <tr>
                    <td><a href="#">BT4 - Tính diện tích</a></td>
                </tr>
                <tr>
                    <td><a href="#">BT5 - Tam giác</a></td>
                </tr>
                <tr>
                    <td><a href="#">BT6 - Số ngày trong tháng</a></td>
                </tr>
                <tr>
                    <td><a href="#">BT7 - Bảng cửu chương</a></td>
                </tr>
                <tr>
                    <td><a href="#">BT8 - Bảng cửu chương NC</a></td>
                </tr>
                <tr>
                    <td><a href="#">BT9 - Số nguyên tố</a></td>
                </tr>
                <tr>
                    <td><a href="#">BT10 - Ngày tháng hiện tại</a></td>
                </tr>
                 <tr>
                    <td><a href="#">BT11 - Biển số xe đẹp</a></td>
                </tr>
                
                <tr>
                	<th><font color="#FF6600">Bài tập PHP-MySQL</font></th>
                </tr>
                <tr>
                    <td><a href="#">Đăng ký thành viên</a></td>
                </tr>
                <tr>
                    <td><a href="#">Chat với bạn bè</a></td>
                </tr>
                <tr>
                    <td><a href="#">Tải sản phẩm miễn phí</a></td>
                </tr>
                <tr>
                    <td><a href="#">Quản trị</a></td>
                </tr>        
                <tr>
                	<th><font color="#FF6600">Bài tập PHP nâng cao</font></th>
                </tr>
                <tr>
                	<td><a href="#" target="_new">Đọc file trên Web</a></td>
                </tr>
                <tr>
                	<td><a href="#">Đọc/ghi nội dung file với PHP</a></td>
                </tr>               
            </table>
        </td>
        <td valign="top" bgcolor="#FFFFFF">
