</td>
<td width="200" valign="top"  bgcolor="#92D84E">	
            <form action="xly_dangnhap.php" name="frmDN" method="post" >
            <table cellpadding="0" cellspacing="0">
            <tr>
            	<th colspan="2"><font color="#ff6600">Đăng nhập</font></th>
             </tr>
             <tr>
                <td>Tân đăng nhập:</td>
                <td><input type="text" name="txtTDNhap" size="12" /></td>
            </tr>
            <tr>
            	<td>Mật khẩu:</td>
                <td><input type="password" name="pswMKhau" size="12" /></td>
            </tr>
            <tr>
            	<td><input type="submit" name="sbmDN" value="Đăng nhập" /></td>
                <td><input type="reset" name="rsHB" value="Hủy bỏ" /></td>
            </tr>
            </table>
            </form>
<table border="1" cellspacing="0" width="100%" cellpadding="0" bordercolor="#003300">
            	<tr>
                	<th><font color="#FF6600">Bài tập giáo trình</font></th>
                </tr>
                <tr>
                    <td><a href="kiem tra so.php">BT - Kiểm tra số</a></td>
                </tr>
                <tr>
                    <td><a href="BT_chuoingaunhien.php">BT - Lấy chuỗi ngẫu nhiên</a></td>
               </tr>
               <tr>
                    <td><a href="BT_kytungaunhien.php">BT - Lấy ký tự ngẫu nhiên</a></td>
               </tr>
               <tr>
               
                   <td><a href="docchuoi_xuatchuoi.php">Đọc chuỗi ký tự</a></td>
                </tr>
                </tr>
            </table>
        </td>
    </tr>
    <tr  bgcolor="#92D84E">
    	<td colspan="3" align="center">
        	CopyRight&copy; sachhay.com <br />
            Design by TrucMaiPham
        </td>
    </tr>
</table>
</center>
</body>
</html>