# Chương trình máy tính đơn giản - PHP

## Nhóm: Câu 1

## Đề bài
Sử dụng PHP để viết chương trình mô phỏng máy tính đơn giản, thực hiện phép tính cộng, trừ, nhân, chia, chia lấy dư (giữ lại form và giá trị trên form sau khi nhập)

## Thành viên nhóm

- **Thành viên 1:** Trầm Khôi Nguyên - 110122126 - DA22TTB
- **Thành viên 2:** Trần Thị Yến Nhi - 110122133 - DA22TTB  
- **Thành viên 3:** Nguyễn Duy Phát - 110122135 - DA22TTB
- **Thành viên 4:** Sơn Ngọc Tân - 110122154 - DA22TTB
- **Thành viên 5:** Nguyễn Đình Nhật Huy - 110122223 - DA22TTB
