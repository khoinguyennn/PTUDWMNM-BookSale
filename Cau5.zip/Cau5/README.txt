Nguyễn Phi Hùng_110122079_DA22TTD.
Đào Công Duy_110122058_DA22TTD.
Câu 5: Viết chương trình cho phép nhập vào 3 cạnh của tam giác. 
Sau đó dùng PHP để xử lý và cho biết có phải là tam giác hay không. 
Nếu là tam giác thì đó là tam giác gì?(Cân, đều, vuông hay thường)

