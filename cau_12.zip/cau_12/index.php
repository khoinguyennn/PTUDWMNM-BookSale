<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Nhập 4 số</h1>
    <form action="process.php" method="post">
        <input type="number" max="9" min="0" name="so1" value="0">

        <input type="number" max="9" min="0" name="so2" value="0">

        <input type="number" max="9" min="0" name="so3" value="0">

        <input type="number" max="9" min="0" name="so4" value="0">

        <input type="submit" value="gửi">
    </form>
</body>
</html>