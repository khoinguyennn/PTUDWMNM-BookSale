DA22TTB
 
Trần Trung Phúc - 110122142
Phan Đăng Khoa - 110122227
Hồ Lý Minh Lữ - 110122231
Nguyễn Hữu Luân - 110122108
Hồ Hoàng Long - 110122107

 Câu 13: Dùng PHP để xây dựng chương trình tính điểm trung binh cho sinh viên trong 1 học kỳ. Biết rằng học kỳ cần tính có 3 môn: Thiết kế web (03 tín chỉ), toán rời rạc (02 tín chỉ), thống kê và phân tích dữ liệu (03 tín chỉ). Biết cách tính điểm trung bình học kỳ = (TKW*3 tín chỉ + TRR * 2 tín chỉ + TKVPTDL * 3 tín chỉ) / (8 tín chỉ)